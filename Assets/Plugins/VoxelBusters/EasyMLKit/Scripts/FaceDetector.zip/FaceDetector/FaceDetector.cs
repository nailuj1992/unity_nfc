﻿using System;
using UnityEngine;
using VoxelBusters.CoreLibrary;
using VoxelBusters.EasyMLKit.Internal;

namespace VoxelBusters.EasyMLKit
{
    /// <summary>
    /// Scan face by passing different input sources.
    /// </summary>
    public class FaceDetector
    {
        public FaceDetectorOptions Options
        {
            get;
            private set;
        }

        private IFaceDetectorImplementation m_implementation;

        /// <summary>
        /// Pass input source to consider for creating a FaceDetector instance.
        /// </summary>
        /// <param name="inputSource"></param>
        public FaceDetector(IInputSource inputSource)
        {
            try
            {
#if !UNITY_EDITOR && UNITY_ANDROID
                m_implementation    = new Implementations.Android.FaceDetectorImplementation(inputSource);
#elif UNITY_EDITOR
                m_implementation = new Implementations.Simulator.FaceDetectorImplementation(inputSource);
#endif
            }
            catch(Exception e)
            {
                DebugLogger.LogError($"[{Application.platform}] Failed creating required implementation with exception : " + e);
            }

            if(m_implementation == null)
            {
                DebugLogger.LogWarning($"[{Application.platform}] Using null implementation as no platform specific implementation found");
                m_implementation = new Implementations.Null.FaceDetectorImplementation(inputSource);
            }
        }

        /// <summary>
        /// Prepare with options. Callback will be called once prepare is complete.
        /// </summary>
        /// <param name="options"></param>
        /// <param name="callback"></param>
        public void Prepare(FaceDetectorOptions options, OnPrepareCompleteCallback<FaceDetector> callback)
        {
            Options = options;
            m_implementation.Prepare(options, (error) => callback?.Invoke(this, error));
        }

        /// <summary>
        /// Start processing the input with the provided options. Callback will be called with FaceDetectorResult once processing has an update/done 
        /// </summary>
        /// <param name="callback"></param>
        public void Process(OnProcessUpdateCallback<FaceDetector, FaceDetectorResult> callback)
        {
            m_implementation.Process((result) => callback?.Invoke(this, result));
        }

        /// <summary>
        /// Shutdown once the processing is done to release resources
        /// </summary>
        /// <param name="callback"></param>
        public void Close(OnCloseCallback<FaceDetector> callback)
        {
            m_implementation.Close((error) => callback?.Invoke(this, error));
        }
    }
}

