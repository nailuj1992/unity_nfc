﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace VoxelBusters.EasyMLKit
{
    public partial class Face
    {
        public class Builder
        {
            private Face m_face;
            public Builder()
            {
                m_face = new Face();
            }

            public Builder SetContours(List<Face.Contour> faceContours)
            {
                m_face.Contours = faceContours;
                return this;
            }

            public Builder SetLandmarks(List<Face.Landmark> faceLandmarks)
            {
                m_face.Landmarks = faceLandmarks;
                return this;
            }

            public Builder SetLeftEyeOpenProbability(float? value)
            {
                m_face.LeftEyeOpenProbability = value;
                return this;
            }

            public Builder SetRightEyeOpenProbability(float? value)
            {
                m_face.RightEyeOpenProbability = value;
                return this;
            }

            public Builder SetSmilingProbability(float? value)
            {
                m_face.SmilingProbability = value;
                return this;
            }

            public Builder SetTrackingId(int? trackingId)
            {
                m_face.TrackingId = trackingId;
                return this;
            }

            public Builder SetBoundingBox(Rect boundingBox)
            {
                m_face.BoundingBox = boundingBox;
                return this;
            }

            public Builder SetHeadEulerAngles(float x, float y, float z)
            {
                m_face.HeadRotation = new Vector3(x, y, z);
                return this;
            }

            public Face Build()
            {
                return m_face;
            }
        }
    }
}