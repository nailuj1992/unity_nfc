﻿using System.Collections.Generic;
using VoxelBusters.CoreLibrary;

namespace VoxelBusters.EasyMLKit
{
    /// <summary>
    /// Result delivered once processing is done for an input instance.
    /// </summary>
    public class FaceDetectorResult
    {
        /// <summary>
        /// Recognized Faces
        /// </summary>
        public List<Face> Faces
        {
            get;
            private set;
        }


        /// <summary>
        /// Error if any, while scanning
        /// </summary>
        public Error Error
        {
            get;
            private set;
        }

        public FaceDetectorResult(List<Face> faces, Error error)
        {
            Faces = faces;
            Error = error;
        }

        /// <summary>
        /// Returns true if there is an error
        /// </summary>
        /// <returns></returns>
        public bool HasError()
        {
            return Error != null;
        }
    }
}