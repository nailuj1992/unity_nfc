﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace VoxelBusters.EasyMLKit
{
    /// <summary>
    /// Options required to set before detecting faces.
    /// </summary>
    public class FaceDetectorOptions
    {
        public enum ClassificationMode
        {
            None = 1,//Default
            All = 2
        }

        public enum PerformanceMode
        {
            Fast = 1,//Default
            Accurate = 2
        }

        public enum ContourMode
        {
            None = 1,//Default
            All = 2
        }

        public enum LandmarkMode
        {
            None = 1,//Default
            All = 2
        }

        public bool IsTrackingEnabled
        {
            get;
            private set;
        }

        public ClassificationMode Classification
        {
            get;
            private set;
        }

        public PerformanceMode Performance
        {
            get;
            private set;
        }

        public ContourMode Contour
        {
            get;
            private set;
        }

        public LandmarkMode Landmark
        {
            get;
            private set;
        }

        public float MinFaceSize
        {
            get;
            private set;
        }

        private FaceDetectorOptions()
        {
        }
        
        public class Builder
        {
            private FaceDetectorOptions m_options;

            public Builder()
            {
                m_options = new FaceDetectorOptions();
            }

            public Builder EnableTracking(bool enable)
            {
                m_options.IsTrackingEnabled = enable;
                return this;
            }

            public Builder SetClassificationMode(FaceDetectorOptions.ClassificationMode classificationMode)
            {
                m_options.Classification = classificationMode;
                return this;
            }

            public Builder SetPerformanceMode(FaceDetectorOptions.PerformanceMode performanceMode)
            {
                m_options.Performance = performanceMode;
                return this;
            }

            public Builder SetContourMode(FaceDetectorOptions.ContourMode contourMode)
            {
                m_options.Contour = contourMode;
                return this;
            }

            public Builder SetLandmarkMode(FaceDetectorOptions.LandmarkMode landmarkMode)
            {
                m_options.Landmark = landmarkMode;
                return this;
            }

            public Builder SetMinFaceSize(float size)
            {
                m_options.MinFaceSize = size;
                return this;
            }

            public FaceDetectorOptions Build()
            {
                return m_options;
            }
        }
    }
}
