﻿#if UNITY_ANDROID
using System;
using System.Collections.Generic;
using System.Globalization;
using UnityEngine;
using VoxelBusters.CoreLibrary;
using VoxelBusters.CoreLibrary.NativePlugins.Android;
using VoxelBusters.EasyMLKit.Implementations.Android.Internal;
using VoxelBusters.EasyMLKit.Internal;
using VoxelBusters.EasyMLKit.NativePlugins.Android;

namespace VoxelBusters.EasyMLKit.Implementations.Android
{
    public class FaceDetectorImplementation : NativeFeatureBase, IFaceDetectorImplementation
    {
        #region Private fields
        
        private bool m_initialised;
        private NativeGoogleMLKitFaceDetector m_instance;
        private OnPrepareCompleteInternalCallback m_prepareCompleteCallback;
        private OnProcessUpdateInternalCallback<FaceDetectorResult> m_processUpdateCallback;
        private OnCloseInternalCallback m_closeCallback;

        #endregion

        public FaceDetectorImplementation(IInputSource inputSource) : base(inputSource)
        {
            m_instance = new NativeGoogleMLKitFaceDetector(NativeUnityPluginUtility.GetContext(), GetNativeInputImageProducer(inputSource));
        }

        public void Prepare(FaceDetectorOptions options, OnPrepareCompleteInternalCallback callback)
        {
            if (!m_initialised)
            {
                Initialise();
            }

            m_prepareCompleteCallback = callback;
            m_instance.Prepare(CreateNativeOptions(options));
        }

        public void Process(OnProcessUpdateInternalCallback<FaceDetectorResult> callback)
        {
            m_processUpdateCallback = callback;
            m_instance.Process();
        }

        public void Close(OnCloseInternalCallback callback)
        {
            m_closeCallback = callback;
            m_instance.Close();

            if(m_closeCallback != null)
            {
                m_closeCallback(null);
            }
        }

        private void Initialise()
        {
            SetupListener();
            m_initialised = true;
        }

        
        private void SetupListener()
        {
            m_instance.SetListener(new NativeGoogleMLKitFaceDetectorListener()
            {
                onScanSuccessCallback = (NativeList<NativeFace> nativeFaces, NativeInputImageInfo inputDimensions) =>
                {
                    if (m_processUpdateCallback != null)
                    {
                        List<Face> faces = GetFaces(nativeFaces.Get(), inputDimensions);
                        Debug.Log("Face list : " + nativeFaces.Get().Count);
                        Callback callback = () => m_processUpdateCallback(new FaceDetectorResult(faces, null));
                        CallbackDispatcher.InvokeOnMainThread(callback);
                    }
                },
                onScanFailedCallback = (NativeException exception) =>
                {
                    if (m_processUpdateCallback != null)
                    {
                        Callback callback = () => m_processUpdateCallback(new FaceDetectorResult(null, new Error(exception.GetMessage())));
                        CallbackDispatcher.InvokeOnMainThread(callback);
                    }
                },
                onPrepareSuccessCallback = () =>
                {
                    if (m_prepareCompleteCallback != null)
                    {
                        Callback callback = () => m_prepareCompleteCallback(null);
                        CallbackDispatcher.InvokeOnMainThread(callback);
                    }
                },
                onPrepareFailedCallback = (NativeException exception) =>
                {
                    if (m_prepareCompleteCallback != null)
                    {
                        Callback callback = () => m_prepareCompleteCallback(new Error(exception.GetMessage()));
                        CallbackDispatcher.InvokeOnMainThread(callback);
                    }
                }
            });
        }

        private List<Face> GetFaces(List<NativeFace> nativeFaces, NativeInputImageInfo inputImageInfo)
        {
            List<Face> faces = new List<Face>();
            foreach(NativeFace nativeFace in nativeFaces)
            {
                Face face = CreateFace(nativeFace, inputImageInfo);
                faces.Add(face);
            }

            return faces;
        }

        private Face CreateFace(NativeFace nativeFace, NativeInputImageInfo inputImageInfo)
        {
            Face.Builder builder = new Face.Builder();
            builder.SetBoundingBox(GetRect(nativeFace.GetBoundingBox(), inputImageInfo));

            builder.SetHeadEulerAngles(nativeFace.GetHeadEulerAngleX(), nativeFace.GetHeadEulerAngleY(), nativeFace.GetHeadEulerAngleZ());
            builder.SetLeftEyeOpenProbability(nativeFace.GetLeftEyeOpenProbability()?.GetFloatValue());
            builder.SetRightEyeOpenProbability(nativeFace.GetRightEyeOpenProbability()?.GetFloatValue());
            builder.SetSmilingProbability(nativeFace.GetSmilingProbability()?.GetFloatValue());
            builder.SetTrackingId(nativeFace.GetTrackingId()?.GetIntValue());
            builder.SetLandmarks(GetLandmarks(nativeFace.GetAllLandmarks().Get(), inputImageInfo));
            builder.SetContours(GetContours(nativeFace.GetAllContours().Get(), inputImageInfo));

            return builder.Build();
        }

        private NativeFaceDetectorScanOptions CreateNativeOptions(FaceDetectorOptions options)
        {
            NativeFaceDetectorScanOptions nativeOptions = new NativeFaceDetectorScanOptions();
            nativeOptions.SetClassificationMode((int)options.Classification);
            nativeOptions.SetContourMode((int)options.Contour);
            nativeOptions.SetLandmarkMode((int)options.Landmark);
            nativeOptions.SetPerformanceMode((int)options.Performance);
            nativeOptions.SetMinFaceSize(options.MinFaceSize);
            nativeOptions.SetTrackingEnabled(options.IsTrackingEnabled);

            return nativeOptions;
        }

        private List<Face.Contour> GetContours(List<NativeFaceContour> nativeFaceContours, NativeInputImageInfo imageInfo)
        {
            List<Face.Contour> contours = new List<Face.Contour>();
            foreach(NativeFaceContour nativeFaceContour in nativeFaceContours)
            {
                Vector2[] points = GetPoints(nativeFaceContour.GetPoints().Get(), imageInfo);
                if(points != null)
                {
                    Face.Contour contour = new Face.Contour((Face.ContourType)nativeFaceContour.GetFaceContourType(), points);
                    contours.Add(contour);
                }
            }

            return contours;
        }

        private List<Face.Landmark> GetLandmarks(List<NativeFaceLandmark> nativeFaceLandmarks, NativeInputImageInfo imageInfo)
        {
            List<Face.Landmark> landmarks = new List<Face.Landmark>();
            foreach (NativeFaceLandmark nativeFaceLandmark in nativeFaceLandmarks)
            {
                Face.Landmark landmark = new Face.Landmark((Face.LandmarkType)nativeFaceLandmark.GetLandmarkType(), GetPoint(nativeFaceLandmark.GetPosition(), imageInfo));
                landmarks.Add(landmark);
            }

            return landmarks;
        }

        private Vector2[] GetPoints(List<NativePointF> nativePoints, NativeInputImageInfo imageInfo)
        {
            if(nativePoints.Count > 0)
            {
                Vector2[] points = new Vector2[nativePoints.Count];

                for(int i=0; i<nativePoints.Count; i++)
                {
                    points[i] = GetPoint(nativePoints[i], imageInfo);
                }
                return points;
            }

            return null;
        }

        private Vector2 GetPoint(NativePointF nativePoint, NativeInputImageInfo imageInfo)
        {
            Vector2 rawPoint = new Vector2(nativePoint.X, nativePoint.Y);
            Vector2 transformedPoint = InputSourceUtility.TransformPointToUserSpace(rawPoint, m_inputSource.GetDisplayWidth(), m_inputSource.GetDisplayHeight(), imageInfo.GetWidth(), imageInfo.GetHeight(), imageInfo.GetRotation());

            return transformedPoint;
        }



        private Rect GetRect(NativeRect nativeRect, NativeInputImageInfo imageInfo)
        {
            Rect rawRect = new Rect(nativeRect.Left, nativeRect.Top, nativeRect.Right - nativeRect.Left, nativeRect.Bottom - nativeRect.Top);
            return InputSourceUtility.TransformRectToUserSpace(rawRect, m_inputSource.GetDisplayWidth(), m_inputSource.GetDisplayHeight(), imageInfo.GetWidth(), imageInfo.GetHeight(), imageInfo.GetRotation());
        }
    }
}
#endif