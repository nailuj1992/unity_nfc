﻿
namespace VoxelBusters.EasyMLKit
{
    using Internal;
    public interface IFaceDetectorImplementation
    {
        void Prepare(FaceDetectorOptions options, OnPrepareCompleteInternalCallback callback);
        void Process(OnProcessUpdateInternalCallback<FaceDetectorResult> callback);
        void Close(OnCloseInternalCallback callback);
    }
}
